import e from "cors";
import { useState } from "react";
import http from "../http";
import Swal from "sweetalert2";
import { useNavigate } from "react-router-dom";
export default function AddProductPage() {
  const [title, setTitle] = useState("");
  const [price, setPrice] = useState("");
  const [image, setImage] = useState("");
  const [description, setDescription] = useState("");
  const [error,setError] = useState("");
  const navigate = useNavigate();

 async function submitHandler(e){
    e.preventDefault();
    //check for empty fields
    if (!title || !price || !description){
      setError("No field should be empty")
      return;
    }

    //send a post request to thr server with the product information
    const {data} = await http.post("/products",{title, price, image});
    if (data, error){
      setError(data.error)
      return;
    }
    if (data.success){
      Swal.fire("Saved", "Product saved successfully", "success")
      navigate("/admin-products")
    }
  }

  return <>
  
  <h1 className="text-center text-black mt-3">Add Product</h1>;
  <form onSubmit={submitHandler} action="" style={{ maxWidth: "750px", margin: "auto" }} className="form">
    {error && <div className="alert alert-danger p-2">{error}</div>}
    <input onChange={(e) => setTitle(e.target.value)} value={title} type="text" className="py-2 form-control mb-3" placeholder="Title"/>
    <input onChange={(e) => setPrice(e.target.value)} value={price} type="number" className="py-2 form-control mb-3" placeholder="price"/>
    <input onChange={(e) => setImage(e.target.value)} value={image} type="text" className="py-2 form-control mb-3" placeholder="image"/>
    <input onChange={(e) => setDescription(e.target.value)} value={description} type="text" className="py-2 form-control mb-3" placeholder="description"/>
    <button className="btn btn-success w-100">Submit</button>
  </form>

  </>
}
